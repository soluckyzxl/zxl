Application related test resources are placed here.

There are two different kinds of resources: main resources and test resources. 
The difference is that the main resources are the resources associated to the 
main source code while the test resources are associated to the test source code.
