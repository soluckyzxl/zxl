package com.example.db;

/**
 * This class is an API layer to the database.
 */
public class DBHelper {
	public String getUserNameById(String user_id) {
		String sUserName = "";

		// connect to DB and lookup the user name by given ID.

		return sUserName;
	}
}
